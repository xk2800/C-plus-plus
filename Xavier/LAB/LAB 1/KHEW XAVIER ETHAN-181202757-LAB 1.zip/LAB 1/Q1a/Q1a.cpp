#include<iostream>
#include<iomanip>
using namespace std;

int main(){

    cout<<"Sales Report for September 15, 2010" << endl;
    cout<<"Artist   Title  Price    Genre   Disc  Sale" << endl;
    cout<<"Merle    Blue   12.99  Country    4%   12.47" << endl;
    cout<<"Richard  Music   8.49  Classical  8%   7.81" << endl;





}