#include<iostream>
using namespace std;
int main()
{     int x = 8, y = 2, z;
cout << ++x << endl;
cout << x << endl;
cout << x-- << endl;
cout << x + y << endl;
cout << x << " "<< y << endl;
cout << "x * x = "; 
cout << x * x << endl;
cout << y++ << endl;
z = x % y;
cout << z << endl;
return 0;
}
